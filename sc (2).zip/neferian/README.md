# B64 Obfuscation

Base64 obfuscate your Py source and run it

# Reverse engineering

This is not the best practice to obfuscate your code, it can be reversed by tools within ease.

# Guide

Put your source into `source.py` and then run `python tobase64,py` afterwards remove `source.py` and run `python index.py`

```py
import base64

def readFile(file='raw.64.txt'):
    content = ""
    with open(file,"rb") as fl:
        content = fl.read()
    return content
# output: #aW1wb3J0IGh0dHB4DQoNCmRlZiByZXEoKToNCiAgICB3aXRoIGh0dHB4LkNsaWVudCgpIGFzIGNsaWVudDoNCiAgICAgICAgcmVwID0gY2xpZW50LmdldCgiaHR0cHM6Ly9nb29nbGUuY29tIixoZWFkZXJzPXsNCiAgICAgI#CAgICAgICdjYWNoZS1jb250cm9sJzogJ25vLWNhY2hlJywNCiAgICAgICAgICAgICd4LWFwaSc6ICdibGEtYmxhJw0KICAgICAgICB9KQ0KICAgICAgICBwcmludChyZXAuc3RhdHVzX2NvZGUsIHJlcC5oZWFkZXJzKQ0KIC# AgIHJldHVybg0KDQppZiBfX25hbWVfXyA9PSAnX19tYWluX18nOg0KICAgIHJlcSgpDQo=
decoded = base64.b64decode(readFile())
exec(decoded)
```

#### Source

```py
import httpx

def req():
    with httpx.Client() as client:
        rep = client.get("https://google.com",headers={
            'cache-control': 'no-cache',
            'x-api': 'bla-bla'
        })
        print(rep.status_code, rep.headers)
    return

if __name__ == '__main__':
    req()
```
