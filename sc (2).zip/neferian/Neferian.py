import base64

def readFile(file='raw.64.txt'):
    content = ""
    with open(file,"rb") as fl:
        content = fl.read()
    return content
exec(base64.b64decode(readFile()))